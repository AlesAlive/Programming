using System;
using System.IO;

namespace game
{
    public class Chislo
    {
        public static void ADD()
        {
            string odin = Console.ReadLine()!;
            string[] choice = odin.Split(" ");

                int count = File.ReadAllLines("data.txt").Length + 1;
                string nomer = count + ". " + choice[0] + " " + choice[1];
                File.AppendAllText("data.txt", nomer + "\n");
        }
        public static void show()
        {
            Console.WriteLine(File.ReadAllText("data.txt"));
        }
        public static void edit()
        {
            string[] lines = File.ReadAllLines("data.txt");

            Console.WriteLine("Enter the line number you want to change");
            if(int.TryParse(Console.ReadLine(), out int linenum) && linenum >= 1 && linenum < lines.Length)
            {
                Console.WriteLine($"current line: {lines[linenum - 1]}");
                Console.WriteLine("Write new name and surname");
                string newline = Console.ReadLine()!;

                lines[linenum -1] = $"{linenum} {newline}";

                File.WriteAllLines("data.txt", lines);
                Console.WriteLine("succesfully added!");
            }
        }
        public static void delete()
        {
            string[] lines = File.ReadAllLines("data.txt");
            Console.WriteLine("Select the line number you want to change");
            
            if(int.TryParse(Console.ReadLine(), out int linenum) && linenum >= 1 && linenum <= lines.Length)
            {
                List<string> list = new List<string>(lines);
                list.RemoveAt(linenum - 1);

                for(int i = 0; i<list.Count; i++)
                {
                    int lineindex = list[i].IndexOf('.');
                    if(lineindex != -1)
                    {
                        list[i] = (i+1) + list[i].Substring(lineindex);
                    }
                }
                File.WriteAllLines("data.txt", list);
                Console.WriteLine("The line was succesfully deleted!");
            }
        }


    }
}