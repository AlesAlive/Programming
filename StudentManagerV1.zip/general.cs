using System;
using System.IO;

namespace game
{
    public class Program
    {
        static void Main()
        {
            if (!File.Exists("data.txt"))
            {
                File.Create("data.txt").Close();
            }
            /*if (!File.Exists("grades.txt"))
            {
                File.Create("grades.txt").Close();
            }*/

        Console.WriteLine("Welcome to the Student Manager!");
        Console.WriteLine("=Select an action:=");
        Console.WriteLine("=1. Add new student=");
        Console.WriteLine("=2. Change student list=");
        //Console.WriteLine("=3. Get student a new grade=");
        Console.WriteLine("=4. Close program=");
            while(true)
        {
        string number = Console.ReadLine()!;

            if (number == "1")
            {
                Console.WriteLine("=Please write new name and surname:=");
                Chislo.ADD();
                Console.WriteLine("=The student was succesfully added!=");
            }
            else if (number == "2")
            {
                Console.WriteLine("=List of students:=");
                Chislo.show();
                Console.WriteLine("=Select an action:=");
                Console.WriteLine("=0.change a student's initials=");
                Console.WriteLine("=00.Delete student=");

                string numbertwo = Console.ReadLine()!;
                if(numbertwo == "0")
                    {
                        Chislo.edit();
                    }
                else if(numbertwo == "00")
                    {
                        Chislo.show();
                        Chislo.delete();
                    }
            }
            if (number == "4")
            {
                break;
            }
        }
        
        }
    }
}
    
